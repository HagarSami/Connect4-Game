# AI-Project
Project of connect4 game
